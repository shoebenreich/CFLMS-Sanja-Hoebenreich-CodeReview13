<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request ;
use  Symfony\Component\HttpFoundation\Response ;
use App\Entity\Events;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;

class EventsController extends AbstractController
{
    /**
     * @Route("/", name="events")
     */
    public function events()
    {
        $events =  $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('events/index.html.twig', array('events'=>$events)
        ); 
    }

    /**
     * @Route("/sports", name="sports")
     */
    public function sports()
    {

        $sports = $this->getDoctrine()->getRepository(Events::class);
        $events = $sports->findByType("sport");

        return $this->render('events/sports.html.twig', array('sports'=>$events)
        );
    }
    /**
     * @Route("/concerts", name="concerts")
     */
    public function concerts()
    {

        $concerts = $this->getDoctrine()->getRepository(Events::class);
        $events = $concerts->findByType("concert");

        return $this->render('events/concerts.html.twig', array('concerts'=>$events)
        );
    }

    /**
     * @Route("/adminpanel", name="admin")
     */
    public function showAll()
    {

        $events =  $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('events/adminpanel.html.twig', array('events'=>$events)
        ); 
    }


   /**
    * @Route("/create", name="createAction")
    */
    public function createAction(Request $request)
    {  
        $event = new Events;
            $form = $this->createFormBuilder($event)
            ->add('name', TextType::class, array('attr' => array('class'=> 'form-control mb-2')))
            ->add('date', DateType::class, array('widget' => 'choice', 'format'=> 'dd MM yyyy', 'attr' => array('class'=>'form-control mb-2')))
            ->add('time',TimeType::class, array('widget' => 'single_text', 'label' => 'Event Time','attr' => array('class'=> 'form-control mb-2')))
            ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control mb-2', 'rows'=> '15', 'cols'=>'50')))
            ->add('image', TextType::class, array('label'=>'Image Path', 'attr' => array('class'=> 'form-control mb-2')))
            ->add('capacity', IntegerType::class, array('label'=>'Capacity', 'attr'=> array('class'=>'form-control mb-2')))
            ->add('contactmail', TextType::class, array('label'=>'Contact Mail','attr' => array('class'=> 'form-control mb-2')))
            ->add('contactnumber', TextType::class, array('label'=>'Contact Number','attr' => array('class'=> 'form-control mb-2')))
            ->add('address', TextType::class, array('label'=>'Address', 'attr'=> array('class'=>'form-control mb-2')))
            ->add('website', TextType::class, array('label'=>'Website', 'attr'=> array('class'=>'form-control mb-2')))
            ->add('type', ChoiceType::class, array('choices'=>array('Concert'=>'Concert', 'Sport'=>'Sport', 'Theatre'=>'Theatre'),'attr' => array('class'=> 'form-control mb-2')))
            ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-success')))
            ->getForm();
            $form->handleRequest($request);
 
            if($form->isSubmitted() && $form->isValid()){
                
                $name = $form['name']->getData();
                $date = $form['date']->getData();
                $time = $form['time']->getData();
                $description = $form['description']->getData();
                $image = $form['image']->getData();
                $capacity = $form['capacity']->getData();
                $contactmail = $form['contactmail']->getData();
                $contactnumber = $form['contactnumber']->getData();
                $address = $form['address']->getData();
                $website = $form['website']->getData();
                $type = $form['type']->getData();


                $event->setName($name);
                $event->setDate($date);
                $event->setTime($time);
                $event->setDescription($description);
                $event->setImage($image);
                $event->setCapacity($capacity);
                $event->setContactMail($contactmail);
                $event->setContactNumber($contactnumber);
                $event->setAddress($address);
                $event->setWebsite($website);
                $event->setType($type);

                $em = $this->getDoctrine()->getManager();
                $em->persist($event);
                $em->flush();
                $this->addFlash(
                        'notice',
                        'Event Added'
                        );
                return $this->redirectToRoute('admin');
            }
    
            return $this->render('events/create.html.twig', array('form' => $form->createView()));
    }

    /**
    * @Route("/update/{id}", name="updateAction")
    */
    public function updateAction($id, Request $request)
    {  
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id); 
        
        $event->setName($event->getName());
        $event->setDate($event->getDate());
        $event->setTime($event->getTime());
        $event->setDescription($event->getDescription());
        $event->setImage($event->getImage());
        $event->setCapacity($event->getCapacity());
        $event->setContactMail($event->getContactMail());
        $event->setContactNumber($event->getContactNumber());
        $event->setAddress($event->getAddress());
        $event->setWebsite($event->getWebsite());
        $event->setType($event->getType());

        $form = $this->createFormBuilder($event)
            ->add('name', TextType::class, array('attr' => array('class'=> 'form-control mb-2')))
            ->add('date', DateType::class, array('widget' => 'choice', 'format'=> 'dd MM yyyy', 'attr' => array('class'=>'form-control mb-2')))
            ->add('time',TimeType::class, array('widget' => 'single_text', 'label' => 'Event Time','attr' => array('class'=> 'form-control mb-2')))
            ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control mb-2', 'rows'=> '15', 'cols'=>'50')))
            ->add('image', TextType::class, array('label'=>'Image Path', 'attr' => array('class'=> 'form-control mb-2')))
            ->add('capacity', IntegerType::class, array('label'=>'Capacity', 'attr'=> array('class'=>'form-control mb-2')))
            ->add('contactmail', TextType::class, array('label'=>'Contact Mail','attr' => array('class'=> 'form-control mb-2')))
            ->add('contactnumber', TextType::class, array('label'=>'Contact Number','attr' => array('class'=> 'form-control mb-2')))
            ->add('address', TextType::class, array('label'=>'Address', 'attr'=> array('class'=>'form-control mb-2')))
            ->add('website', TextType::class, array('label'=>'Website', 'attr'=> array('class'=>'form-control mb-2')))
            ->add('type', ChoiceType::class, array('choices'=>array('Concert'=>'Concert', 'Sport'=>'Sport', 'Theatre'=>'Theatre'),'attr' => array('class'=> 'form-control mb-2')))
            ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-success')))
            ->getForm();
            $form->handleRequest($request);

            if($form->isSubmitted() && $form->isValid()){
                
                $name = $form['name']->getData();
                $date = $form['date']->getData();
                $time = $form['time']->getData();
                $description = $form['description']->getData();
                $image = $form['image']->getData();
                $capacity = $form['capacity']->getData();
                $contactmail = $form['contactmail']->getData();
                $contactnumber = $form['contactnumber']->getData();
                $address = $form['address']->getData();
                $website = $form['website']->getData();
                $type = $form['type']->getData();


                $event->setName($name);
                $event->setDate($date);
                $event->setTime($time);
                $event->setDescription($description);
                $event->setImage($image);
                $event->setCapacity($capacity);
                $event->setContactMail($contactmail);
                $event->setContactNumber($contactnumber);
                $event->setAddress($address);
                $event->setWebsite($website);
                $event->setType($type);

                $em = $this->getDoctrine()->getManager();
                $em->flush();
                $this->addFlash(
                        'notice',
                        'Event Added'
                        );
                return $this->redirectToRoute('admin');

            }
        
        return $this->render('events/edit.html.twig', array('Events' => $event, 'form' => $form->createView()));

    }

      /**
    * @Route("/delete/{id}", name="todo_delete")
    */
   public function deleteAction($id){

        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository('App:Events')->find($id);
        $em->remove($event);
        $em->flush();
        $this->addFlash(
            'notice',
            'Event Removed'
            );
        return $this->redirectToRoute('admin');
}



    /**
    * @Route("details/{id}", name="details_page")
    */
   public function detailsAction($id)
   {
       $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
       return $this->render('events/details.html.twig', array('event'=>$event));
   }
}
